--beginning of fish script

--animation variables
local idle = animations.fish_model.idle
local float = animations.fish_model.float
--boolean variables
local swapAnim = false;
local setFishVisible = true;
local scaleFish = false;

--render function
function events.render(delta, context)
  if player:isLoaded() then
--sets fish visibility
	if setFishVisible == false then
		models.fish_model:setVisible(false)
		idle:stop()
		float:stop()
	else
		models.fish_model:setVisible(true)
		end
--swap for idle/float anim
	if swapAnim == false then
		idle:play()
		float:stop()
	else
		float:play()
		idle:stop()
		end
-- scaling
	if scaleFish == false then
		models.fish_model:setScale(1, 1, 1)
	else
		models.fish_model:setScale(1.5, 1.5, 1.5)
		end
	end
end

--action wheel

local pageFish = action_wheel:newPage()

action_wheel:setPage(pageFish) --setting as main page

--idle/float animation swap
local action = pageFish:newAction()
	:title("Swap Fish Animation")
    :item("minecraft:tropical_fish")
    :hoverColor(1,0,1)
    :onLeftClick(
        function()
			swapAnim = not swapAnim;
        end
    )

--fish visibility
local action = pageFish:newAction()
	:title("Turn Fish Off")
    :item("minecraft:bucket")
    :hoverColor(1,0,1)
    :onLeftClick(
        function()
			setFishVisible = not setFishVisible;
        end
    )

--fish size scale
local action = pageFish:newAction()
	:title("Scale Fish Size")
    :item("minecraft:potion")
    :hoverColor(1,0,1)
    :onLeftClick(
        function()
			scaleFish = not scaleFish;
        end
    )
	
--the end of fish script
	