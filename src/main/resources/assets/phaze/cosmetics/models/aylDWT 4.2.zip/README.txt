How to ask for help in the Discord server:
*DO NOT* say "this is broken" with no elaboration. Every time someone does this, 1 year is shaved off my lifespan.
> Explain what you expected to happen and what actually happened clearly.
*DO NOT* say you have a problem without mentioning if you modified the avatar in any way. Every time someone does that, a fairy dies.
> Explain what you changed (or if you didn't change anything).

# FAQ
**How do I install this?**
1. Download the Figura mod for your version of minecraft / mod loader
2. Go into a world and click the blue triangle in the pause menu to get to the wardrobe menu
3. Click the folder icon that will take you to your .minecraft/figura/avatars folder. Copy-paste the downloaded zip in that folder.
4. Select aylFAW in the wardrobe menu (if you want to have it automatically selected every time you start up, upload it to the cloud with the white upload button at the bottom).

**How do I use the skins?**
1. Go into the folder named skins.
2. Copy the contents of the folder for the skin you want. Don't copy the folder itself, only the contents.
3. Paste your copied texture files into the main model's textures folder, replacing the old texture files.

**How do I retexture a skin?**
1. Look at all the skins and pick the best one to use as a base for retexturing. This will save you a shitton of time.
2. Download blockbench and the Figura v5 addon (look at **Cannot invoke "String.isEmpty()" because "$$0" is null"** in # Errors for instructions on how to download the v5 addon)
3. Open model.bbmodel in blockbench and go to the paint tab. Start repainting the textures.
4. Make sure to use Ctrl+S to save the textures.

**How do I add this to another avatar?**
File explorer
1. Copy the scripts folder, textures folder, and the script.lua to your new avatar folder.
2. Open the script.lua (you can do this with notepad) and ctrl+F the phrase "Adding to another model" (without the quotation marks).
3. Delete everything it tells you to delete.
Bbmodel
2. Ctrl+C ctrl+V the parts you want to add onto your new model. They need to be in the same .bbmodel file (which *must* be named model.bbmodel and not say, FunnyModel.bbmodel) as your player model or the animators won't work.
3. Ctrl+C ctrl+V all the animations to your new model.
If your model's Head, Body, RightArm, LeftArm, RightLeg, and LeftLeg folders are named something different, their keyframes won't automatically copy over. They have keyframes in all animations starting with fly*, as well as the flap animation. You need to paste these keyframes over to your new model's animations manually.
4. Save your file, including the textures. You can do this with Ctrl+S.

**How do I add something to the action wheel?**
The main page's variable is named pages.main.page, and the setting page's variable is pages.settings.page. If you want to add to another page, ctrl+F "dPages" without the quotes in the script.lua. The notation goes pages.[key].page.
So for example, to add an action to the main page, you'd do:
local action = pages.main.page:newAction()
  :title("My Action")
  :item("minecraft:stick")
If you want to make it fit with the other configs, however... uh, good luck. Just mess around with duplicating stuff in dConfigs and you'll get it eventually.

# Problems
**My model is broken for other people, but not for me!**
https://discord.com/channels/1129805506354085959/1488477253053714513/1494098875978354709
On your friend's side, your nameplate probably has a little 🛡️ symbol next to it. This means that the permission level they've given you isn't high enough for this avatar to function.
1. Your friend needs to up your permission level in the permission screen. Tell them to drag you to max permissions and right click reload.

**My model is pitch black!**
1. Go into scripts/aylSharedCode.lua, ctrl+F "My model is pitch black" without the quotation marks and delete everything it tells you to delete.

**My model is pitch black, but only in menus!**
Unfortunately, there's nothing I can do about this. Figura's paperdoll emissive rendering is broken in versions below 1.21.4.

# Errors
Getting an error? The first thing you should always do before asking someone else is to redownload the avatar and try again. In at least 75% of circumstances this will probably work.

**config:load(key .. "Config") == nil**
https://discord.com/channels/1129805506354085959/1487720759659991081/1490911580010057863
  Reason
    libs/aylConfig:26 Failed to load avatar data file
  stack traceback:
    libs/aylConfig:26: in function 'settings'
    libs/aylConfig:84: in function 'initialize'
    script:91: in main chunk
  script:
    if config:load(key .. "Config") == nil then
1. Go into figura/config and delete the config json corresponding to the avatar.

**Cannot invoke "String.isEmpty()" because "$$0" is null"**
https://discord.com/channels/1129805506354085959/1487720759659991081/1488634817942917331
  Loading Error
  Reason
    Invalid model
    Cannot invoke "String.isEmpty()" because "$$0" is null
OR
**The return value of "com.google.gson.JsonObject.get(String)" is null**
https://discord.com/channels/1129805506354085959/1488477253053714513/1494742868764393712
  Loading Error
  Reason
    Invalid model
    Cannot invoke "com.google.gson.JsonElement.getAsJsonArray()"
  because the return value of
    "com.google.gson.JsonObject.get(String)" is null
Your blockbench model was saved using a version of Blockbench that is incompatible with Figura. The latest blockbench version is incompatible with Figura.
Only the person uploading the avatar (most likely you) requires the addon mod as it will fix the avatar before it is uploaded for others to see.
The support addon goes alongside Figura, it doesn't replace Figura.
You also have the option to downgrade Blockbench to the last compatible version, which is 4.12.6.
1. Your easiest solution is to download the Figura v5 support mod from Modrinth. Click the bright green Download button and select your modloader.
  https://modrinth.com/mod/figura-v5-support

**Blockbench model couldn't be found**
Reason
  scripts/aylSharedCode:2 The blockbench model provided couldn't be found because it has no animations, or because of a typo or some other mistake. stack traceback:
  scripts/aylSharedCode:2: in main chunk
script:
  EZModel = EZAnims:addBBModel(animations.model)
You renamed model.bbmodel to something else.
1. Rename it back to model.bbmodel.

**Tried to require nonexistent script EZAnims**
https://discord.com/channels/1129805506354085959/1487720759659991081/1493052645932273766
  Reason
    aylSharedCode:1 Tried to require nonexistent script "scripts/EZAnims"!
  stack traceback:
    aylSharedCode:1: in main chunk
  script:
    EZAnims = require("scripts.EZAnims")
Either one of two things is happening:
1. You're adding this to another avatar and your lua scripts aren't in the correct folder. They need to be *specifically* in the /scripts folder and not in, say, your avatar's root folder, or in a subfolder.
2. You've just downloaded this model with no modifications and it's giving you this error for some reason. Unfortunately, I don't have a solution for this as I can't replicate it myself. Sorry! You're doomed. Try asking in #❓technical-hellp if you really want to try and fix it yourself.