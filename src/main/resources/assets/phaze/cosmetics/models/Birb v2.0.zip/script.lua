local dronezAPI = require("dronezAPI")
local runLater = require("runLater")
local idle = animations.model.BirbIdle:play()

local droneObject = dronezAPI.new(models.model.WORLD)
	:setLocalOffset(0,0.3,0)
	:setTopSpeed(2)
    :setAcceleration(0.12)
	:setBrakeMultiplier(1)
	:setWarpThreshold(48)
	:setAquireWaitTime(math.huge)
	:setTargetPosFunction(dronezAPI.targetFunctions.followEntity)
	:setTargetRotFunction(dronezAPI.targetFunctions.lookAt)


function droneObject.dronePunched(droneObj, interactor)
	animations.model.BirbBite:play()
	sounds:playSound("minecraft:entity.ender_dragon.hurt", droneObj.pos, 0.5, 1.5)
	sounds:playSound("minecraft:entity.ender_dragon.growl", droneObj.pos, 0.5, 2)
	droneObj.targetEntity = interactor
	runLater(15, function() sounds:playSound("minecraft:entity.evoker_fangs.attack", droneObj.pos, 0.5, 1) end)
	return 0
end

function events.tick()
	if animations.model.BirbBite:isPlaying() then
		models.model.WORLD.Birb:setColor(150 / 255, 0 / 255, 0/255)
	else
		models.model.WORLD.Birb:setColor(255 / 255, 255 / 255, 255 / 255)
		droneObject.targetEntity = player
	end
end