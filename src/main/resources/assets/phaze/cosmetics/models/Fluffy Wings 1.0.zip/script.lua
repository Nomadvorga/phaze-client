-- Scripted and Modeled by CodexCracked Mon, Apr 6, 2026

--libs
require("GSAnimBlend")

--model setup
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)
if icarus then
    icarus:setWingsVisible(false)
end
local wingmodel = models.fluffywings
local anim = animations.fluffywings
local flyState
local expecFlap
anim.dive:setBlendTime(7)

--switch statement setup
local function switch(value)
	-- Handing `cases` to the returned function allows the `switch()` function to be used with a syntax closer to c code (see the example below).
	-- This is because lua allows the parentheses around a table type argument to be omitted if it is the only argument.
	return function(cases)

		-- The default case is achieved through the metatable mechanism of lua tables (the `__index` operation).
		setmetatable(cases, cases)

		local f = cases[value]
		if f then
			f()
		end
	end
end

--== scriptin ==--

local forwardKeyState = false
function pings.examplePing(state)
    forwardKeyState = state
end
local exampleKey = keybinds:newKeybind("Forwards key", keybinds:getVanillaKey("key.forward"))
exampleKey.press = function()
    pings.examplePing(true)
end
exampleKey.release = function()
    pings.examplePing(false)
end

function FlapComplete()
  --log("Complete!", expecFlap, flyState)
  if flyState == "FLAP" and expecFlap >= 1 then
    --log("Flapping!")
    anim.flap:play()
  end
  if (flyState ~= "FLAP") or (expecFlap == 0) then
    --log("Stopping!")
    anim.flap:stop()
  end
  expecFlap = expecFlap - 1
end

function events.tick() --behold, my tick function. look upon it, ye mighty, and weep
  local speed = vectors.vec3(math.abs(player:getVelocity()[1]),math.abs(player:getVelocity()[2]),math.abs(player:getVelocity()[3])) -- getting the player's velocity and assigning it to this variable
  local totalspeed = speed[1]+speed[2]+speed[3] --all the speed
  local neglookvirt = math.clamp(player:getLookDir()[2], -1, 0)
  local diveDir = -0.3 --how far down the player has to be looking for dive to activate
  local flapPrereq = 2 --how fast the player has to be going for flap to activate
  local flappyBlendEQ = (totalspeed+0.3) / 2.5
  local flappyBlend = math.clamp(flappyBlendEQ, 0.5, 1.3) --final blend clamp
  if not player:isGliding() then --hey are we flying or
    flyState = "GROUNDED"
  elseif player:getLookDir()[2] <= diveDir then --highest priority, if facing down far enough, so dive overrides other states
    flyState = "DIVE"
  elseif forwardKeyState then --second priority, if w key is pressed
    flyState = "FLAP"
    expecFlap = 1
  elseif (totalspeed > flapPrereq) and (flyState ~= "FLAP") then -- third priority, flap at high speeds, like when a rocket is used or returning from a dive
    flyState = "FLAP"
    expecFlap = 3
  elseif expecFlap == 0 then --lowest priority, gliding
    flyState = "GLIDE"
  end

  switch(flyState) {--switch statement for governing what to do during each state
    ["GROUNDED"] = function()
      --log("Case Ground")
      anim.dive:stop()
      anim.glide:stop()
    end,
    ["FLAP"] = function()
      --log("Case Flap")
      if anim.flap:isPlaying() == false and expecFlap ~= 0 then
        anim.flap:play()
        anim.flap:setBlend(flappyBlend)
      end
    end,
    ["DIVE"] = function()
      --log("Case Dive")
      anim.dive:play()
      anim.dive:setBlend(math.abs(neglookvirt) * 1.5)
      anim.glide:stop()
    end,
    ["GLIDE"] = function()
      --log("Case Glide")
      anim.glide:play()
      anim.dive:stop()
    end,
    __index = function()
      log("Error: State outside expected range. This is likely because the player is not loaded yet. Press F3+D to clear your chat.")
    end
  }
end

--== Wheel Pings ==--
function pings.cupid()
  wingmodel:setPrimaryTexture("Custom", textures["fluffywings"])
  wingmodel:setSecondaryTexture("Custom", textures["fluffywings_e"])
end

function pings.crow()
  wingmodel:setPrimaryTexture("Custom", textures["crowwings"])
  wingmodel:setSecondaryTexture("Custom", textures["crowwings_e"])
end

function pings.fire()
  wingmodel:setPrimaryTexture("Custom", textures["phoenixwings"])
  wingmodel:setSecondaryTexture ("Custom", textures["phoenixwings_e"])
end

function pings.owl()
  wingmodel:setPrimaryTexture("Custom", textures["owlwings"])
  wingmodel:setSecondaryTexture("Custom", textures["owlwings_e"])
end

--== Wheel Setup ==--
local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

--== Main Page ==--
local action = mainPage:newAction()
:title("Owl Wings")
:item("minecraft:wheat")
:onLeftClick(pings.owl)

local action = mainPage:newAction()
:title("Crow Wings")
:item("minecraft:flint")
:onLeftClick(pings.crow)

local action = mainPage:newAction()
:title("Cupid Wings")
:item("minecraft:feather")
:onLeftClick(pings.cupid)

local action = mainPage:newAction()
:title("Phoenix Wings")
:item("minecraft:blaze_powder")
:onLeftClick(pings.fire)
